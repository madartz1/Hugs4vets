# HUGS4VETS — Brand Structure + Website

This folder is a **4-page static website** ready to upload to Netlify.

## Brand Structure (Suggested)

### Brand Name
**HUGS4VETS**

### Meaning / Acronym
**H.U.G.S. — Help Under Good Service**

### Mission
Connect veterans and their families to **trusted support pathways**: benefits, crisis help, wellness tools, and community services.

### Vision
A world where every veteran has **fast access to care, benefits, and a strong local support network**.

### Values
- **Dignity First** — Respect, privacy, non-judgment
- **Trust + Transparency** — Official sources, clear disclaimers
- **Action > Performance** — Practical next steps
- **Community Powered** — Peer support and local partners

### Primary Audiences
- Veterans and their families
- Caregivers and supporters
- Community partners and volunteers

### Program Pillars
1. **Government Support**: VA health care, benefits, crisis support, directories
2. **Community Support**: vetted veteran orgs, peer networks, housing/employment help
3. **Wellness**: Whole Health and evidence-based wellness resources
4. **Local Outreach (optional)**: events, clothing/merch drops, resource drives

### Brand Voice
Grounded, respectful, calm, action-oriented.

### Monetization (optional)
- Merch fundraising (hoodies, patches)
- Sponsorships and partner referrals
- Donations (if nonprofit)

## Pages
- `index.html` — Home
- `government-support.html` — Official VA + government links
- `community-support.html` — Trusted organizations and networks
- `wellness.html` — Whole Health + wellness blog links

## Netlify Upload
1. Zip this folder.
2. In Netlify: **Add new site → Deploy manually → drag-and-drop the zip**.

## Replace the logo
Current logo file: `assets/logo.jpeg`
Replace with your clean (non-watermarked) final logo anytime.
